# Reproducibility bundle — ECM wind-heatwave WERR study

Boundary: raw ERA5 (~110 monthly files/variable set) and OPSD source files
are re-acquired via scripts/dl_era5.py (ARCO zarr, anonymous) and the
documented public sources (docs/data_sources.md); they are NOT shipped here.
All derived CSVs in data/ + results/ are included with SHA-256 provenance
ledger (data/processed_ledger.json). Production WRF was NOT executed —
wrf/ contains production namelists, scenario generator and COMPUTE_BUDGET.md.

Rebuild order: make analysis -> make revision -> make figures -> make
manuscript -> make qc (requires data/raw inputs or the shipped processed
products for downstream steps). Seed 20260924 everywhere.
