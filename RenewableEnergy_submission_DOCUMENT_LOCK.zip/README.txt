Renewable Energy submission set (single-anonymized review).
manuscript.docx - title page (author placeholder), abstract, keywords, highlights,
  main text, tables, figure captions/figures, declarations, references.
cover_letter.docx/.md, highlights.txt, graphical_abstract.pdf/.png,
figures/Figure_1..8.png (separate artwork files) + figures_editable.pptx,
references_verified.csv (Crossref-verified bibliography).
Author to complete in Editorial Manager: name/affiliation/ORCID, GenAI declaration.
